import { Navigate } from "react-router-dom";
import { useAuth } from "./AuthProvider";

export default function ProtectedRoute({ children }) {
  const { user } = useAuth();
  const accessToken = localStorage.getItem("accessToken");

  if (!user || !accessToken) {
    return <Navigate to="/login" replace />;
  }

  return children;
}
