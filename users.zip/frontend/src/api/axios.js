import axios from "axios";

//protect agains csrf token -> unauthorized requests from other sites
function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    const cookies = document.cookie.split(";");
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      //"csrftoken="
      if (cookie.startsWith(name + "=")) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}


const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  headers: {
    "Content-Type": "application/json",
  },
  withCredentials: true,
});
//where to go
axiosInstance.interceptors.request.use(
  (config) => {
    const csrfToken = getCookie("csrftoken");
    const accessToken = localStorage.getItem("accessToken");

    if (csrfToken) {
      config.headers["X-CSRFToken"] = csrfToken;
    }

    if (accessToken) {
      config.headers["Authorization"] = `Bearer ${accessToken}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);


axiosInstance.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 429){
      alert("Too many tries. Please try to login again later.");
      return Promise.reject(error);
    }

    if(error.response?.status === 400){
      const message = error.response.data?.detail || "The request is not valid. Please verify the input data.";
      alert(message);
      return Promise.reject(error);
    }

    //response of  unauthorized
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      console.warn("Access token expired. Attempting refresh...");
    

      try {
        //if the refresh token is missing
        const refreshToken = localStorage.getItem("refreshToken");
        if (!refreshToken) {
          console.error("No refresh token found in localStorage");
          throw new Error("No refresh token available");
        }
        
        const refreshResponse = await axios.post(
          `${import.meta.env.VITE_API_URL}token/refresh/`,
          { refresh: refreshToken } //get the refresh token 
        );
        //set the access token as the refresh token
        const newAccessToken = refreshResponse.data.access;
        localStorage.setItem("accessToken", newAccessToken);
        console.log("Token refreshed successfully");
        //resend the original request with the new token
        axiosInstance.defaults.headers["Authorization"] = `Bearer ${newAccessToken}`;
        originalRequest.headers["Authorization"] = `Bearer ${newAccessToken}`;

        return axiosInstance(originalRequest);
      } catch (refreshError) {
        
        console.error("Refresh token failed:", refreshError);
        //remove tokens from local storage of web page
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");

        // Redirect la login
        window.location.href = "/login?expired=true";
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;
