from django.db import models
from django.conf import settings
from users.models.core import Course, User
from django.core.exceptions import ValidationError

class Question(models.Model):
    QUESTION_TYPES=[
        ('single', 'Single Choice'),
        ('multiple', 'Multiple Choice'),
        ('open', 'Open Answer')
    ]

    text = models.TextField(blank=True, null=False)
    type = models.CharField(max_length=10, choices=QUESTION_TYPES)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="questions")
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="questions")
    is_shared = models.BooleanField(default=False)
    is_generated_ai = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f" {self.text[:50]}"
    
    def clean(self):
        if self.pk:
            options = AnswerOption.objects.filter(question = self)
            correct_count = options.filter(is_correct = True).count()

            if self.type == 'single' and correct_count!=1:
                raise ValidationError("Single choice questions must have exactly one correct answer.")
            elif self.type == 'multiple' and correct_count < 1:
                raise ValidationError("Multiple choice questions must have at least one correct answer.")

class AnswerOption(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    text = models.CharField(max_length=512, null=False, blank=True)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return f"Option for Q{self.question.id}: {self.text[:30]}"
    
    class Meta:
        unique_together = ('question', 'text')
            